package com.webaddicted.rallis

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
