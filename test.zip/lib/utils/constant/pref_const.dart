class PrefConst {
  static String prefAccessToken = "PREF_ACCESS_TOKEN";
  static String prefCustomerId = "PREF_CUSTOMER_ID";
  static String prefName = "PREF_NAME";
  static String prefEmail = "PREF_EMAIL";
  static String prefDob = "PREF_DOB";
  static String prefMobile = "PREF_MOBILE";
  static String prefAddress = "PREF_ADDRESS";
  static String prefPassword = "PREF_PASSWORD";
  static String prefImage = "PREF_IMAGE";
}
